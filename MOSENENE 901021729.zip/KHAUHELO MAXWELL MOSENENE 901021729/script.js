const menuButton = document.getElementById("menuButton");
const navigation = document.getElementById("navigation");

if (menuButton && navigation) {

    menuButton.addEventListener("click", function () {

        navigation.classList.toggle("show");

    });

}

document.querySelectorAll(".year").forEach(function (item) {

    item.textContent = new Date().getFullYear();

});


const searchInput = document.getElementById("searchInput");

if (searchInput) {

    searchInput.addEventListener("input", function () {

        const cards = document.querySelectorAll(".experience-card");

        const searchText = searchInput.value.toLowerCase();

        cards.forEach(function (card) {

            if (card.textContent.toLowerCase().includes(searchText)) {

                card.style.display = "";

            } else {

                card.style.display = "none";

            }

        });

    });

}

const contactForm = document.getElementById("contactForm");

if (contactForm) {

    contactForm.addEventListener("submit", function (event) {

        event.preventDefault();

        const name = document.getElementById("visitorName").value.trim();

        const email = document.getElementById("visitorEmail").value.trim();

        const message = document.getElementById("visitorMessage").value.trim();

        const result = document.getElementById("resultMessage");


        if (name === "" || email === "" || message === "") {

            result.textContent = "Please complete all required fields.";

        }

        else if (!email.includes("@") || !email.includes(".")) {

            result.textContent = "Please enter a valid email address.";

        }

        else {

            result.textContent = "Thank you, " + name + ". Your form has been checked successfully.";

            contactForm.reset();

        }

    });

}

function calculateTrip() {

    
    let people = Number(document.getElementById("people").value);
    let nights = Number(document.getElementById("nights").value);
    let days = Number(document.getElementById("days").value);

    let accommodation = Number(document.getElementById("accommodation").value);
    let guide = Number(document.getElementById("guide").value);
    let food = Number(document.getElementById("food").value);

    
    if (people < 1 || nights < 1 || days < 1 ||
        !Number.isInteger(people) ||
        !Number.isInteger(nights) ||
        !Number.isInteger(days)) {

        alert("Please enter valid positive whole numbers.");
        return;
    }

    
    let accommodationTotal = accommodation * people * nights;
    let guideTotal = guide * days;
    let foodTotal = food * people * days;

    
    let total = accommodationTotal + guideTotal + foodTotal;

    
    document.getElementById("accommodationCost").innerHTML =
        "Accommodation: M" + accommodationTotal.toLocaleString();

    document.getElementById("guideCost").innerHTML =
        "Tour Guide: M" + guideTotal.toLocaleString();

    document.getElementById("foodCost").innerHTML =
        "Food: M" + foodTotal.toLocaleString();

    document.getElementById("totalCost").innerHTML =
        "Total: M" + total.toLocaleString();
}

const themeButton = document.getElementById("themeButton");

const savedTheme = localStorage.getItem("websiteTheme");

if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
}

if (themeButton) {

    if (document.body.classList.contains("dark-mode")) {
        themeButton.textContent = "☀️ Light Mode";
    }

    themeButton.addEventListener("click", function () {

        document.body.classList.toggle("dark-mode");

        if (document.body.classList.contains("dark-mode")) {

            localStorage.setItem("websiteTheme", "dark");
            themeButton.textContent = "☀️ Light Mode";

        } else {

            localStorage.setItem("websiteTheme", "light");
            themeButton.textContent = "🌙 Dark Mode";

        }

    });
}
